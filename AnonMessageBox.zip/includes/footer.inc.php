<div class="container-fluid bg-dark text-white mt-5">
<div style="padding:20px;">
  <div class="d-flex justify-content-center align-items-center mb-2">
    <a class="link" href="#"><i style="color:#fff;font-size:25px;" class="fa-brands fa-facebook"></i></a>
    <a style="margin-left:30px;margin-right:30px;" class="link" href="#"><i style="color:#fff;font-size:25px;" class='fa-brands fa-square-x-twitter'></i></a>
    <a class="link" href="#"><i style="color:#fff;font-size:25px;" class='fa-brands fa-telegram'></i></a>
  </div>
  <div class="text-center">
  <span style="font-size:14px" class="me-2">Copyright &copy; <span class='current_year'></span> AnonMessageBox. All right reserved.</span>
  </div>
</div>
</div>
<script>
var c_year = new Date().getFullYear();
var current_year = document.querySelector(".current_year");
current_year.innerHTML = c_year;
</script>