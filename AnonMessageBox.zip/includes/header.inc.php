<!-- header -->
<div style="background:#002333;padding:10px" class="text-center text-white">
   <div class="d-flex align-items-center justify-content-between">
      <i style="font-size:20px;" class="fa-solid fa-envelope-open-text"></i>
      <a class="text-decoration-none text-white" href="index.php"><span style="font-size:16px;margin-left:10px;">Anon Message Box</span></a>
      <a class="text-decoration-none text-white" href="about_us.php"><i style="font-size:20px;" class="fa-solid fa-circle-info"></i></a>
   </div>
</div>